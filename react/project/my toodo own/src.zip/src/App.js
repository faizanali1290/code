import { useState } from "react"
import "./App.css"

function App() {

  let [listOfTodo, setListOfTodo] = useState('')

  let [listItems, setListItems] = useState([])

function formvalue(e){
  
    setListOfTodo(e.target.value)
  
}

  function addTodoList(){

if(listOfTodo===''){

  alert('eiohnasdvkc ')
}
else{

  setListItems([...listItems,listOfTodo])

}

  }



  return (
    <div>
      <h1>Todo List</h1>



      
        <input type="text" onChange={formvalue} placeholder='add a list' value={listOfTodo} />

        <button type="submit" onClick={addTodoList} className="addButton">+</button>





      <div>
        <ul>
{

          listItems.map((items, index) => {


function remove(){

  const filterOut= listItems.filter((data, dataindex) => {

return dataindex != index





})
  setListItems(filterOut)



}









            

            return (
              <div >
                <li >{items}</li>
                <button onClick={remove} >-</button>
                {/* <button >check</button> */}
              </div>
            )
          }) }
          
        </ul>
      </div>

    </div>
  )



}


export default App
