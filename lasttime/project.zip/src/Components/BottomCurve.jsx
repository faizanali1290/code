import React from "react";

const Bottomcurve = () => {
  return <div className="bottom-curve"></div>;
};

export default Bottomcurve;
