import React from "react";

const Topcurve = ({ name }) => {
  return <h2 className="top-curve">{name}</h2>;
};

export default Topcurve;
